Assignment 2 - Waka Waka Extension Changes

- SodaCan is represented by 's' character in map files
- length of mode is described in config.json file under the tag "invisLength"
- Uses two sprites - sodacan.png and sodacaneaten.png - representing a soda
  and a squashed can respectively.
